function printALL(obj) {
    obj.print();
}
var circle = {
    print: function () {
        console.log("print() called from circle object ");
    }
};
var employee = {
    print: function () {
        console.log("print() called from employee object");
    }
};
printALL(circle);
printALL(employee);
