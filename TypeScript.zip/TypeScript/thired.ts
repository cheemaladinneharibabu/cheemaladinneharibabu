interface Printable {
    print():void;
}
function printALL(obj:any){
    obj.print();
}
var circle:printable=
{
    print:function(): void {
        console.log("print() called from circle object ");
    }
}
var employee : Printable={
    print: function():void{
        console.log ("print() called from employee object");
    }
}
printALL(circle);
printALL(employee);