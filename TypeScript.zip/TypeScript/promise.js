var p1 = new Promise(function (resolve, reject) {
    setTimeout(function () {
        var a1 = 10;
        console.log('The first promise has resolved');
        resolve(a1);
    }, 1 * 1000);
});
var p2 = new Promise(function (resolve, reject) {
    setTimeout(function () {
        console.log('The second promise has resolved');
        resolve(20);
    }, 2 * 1000);
});
Promise.all([p1, p2]).then(function (results) {
    var total = results.reduce(function (p, c) { return p + c; });
    console.log("Results: ".concat(results));
    console.log("Total: ".concat(total));
});
