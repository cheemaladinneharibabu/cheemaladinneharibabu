import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { HotelMangementServicesService } from '../services/hotel-mangement-services.service';

@Component({
  selector: 'app-setrates',
  templateUrl: './setrates.component.html',
  styleUrls: ['./setrates.component.css']
})
export class SetratesComponent implements OnInit {

  roomtype: any;
  adults: any;
  child: any;
  standardprice: any;
  successfullySubmited = false;

  
  routeParameter: any;
  ReceptionistUser: any;
  addsetRatesSubscription: Subscription = new Subscription;
  errorsetRatesAdding = false;
  showError = false;
  // updateReceptionistSubscription: Subscription = new Subscription;

  constructor(public managesetRates: HotelMangementServicesService, private activeRoute: ActivatedRoute, public router: Router) { }


  ngOnInit(): void {
    console.log('setrates loaded');
    
    this.activeRoute.params.subscribe(routeParams => {
      this.routeParameter = routeParams['id'];
    });
  }
  onSetratesFormSubmit(setRatesDetails: any) {
    console.log("details", setRatesDetails.value);
    this.errorsetRatesAdding = false;
    this.successfullySubmited = false;
    let isValid = true;
    if (setRatesDetails.valid) {
      this.showError = false;
    } else {
      isValid = false;
      this.showError = true;
    }
    
    if (isValid) {
      this.addsetRatesSubscription = this.managesetRates.AddRates(setRatesDetails.value).subscribe((data: any) => {
        console.log("response", data);
        this.successfullySubmited = true;
        setRatesDetails.reset();
      },error =>{
        this.errorsetRatesAdding = true;
      });
    }

  }
}
