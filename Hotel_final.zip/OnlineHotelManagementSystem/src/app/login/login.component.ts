import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { HotelMangementServicesService } from '../services/hotel-mangement-services.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  optedRole = "owner";
  roles = ['owner','manager','staff'];
  email:any="";
  password:any="";
  addloginSubscription:Subscription = new Subscription;
  routeParameter: any;
  errorLoginservice = false;
  
  constructor(public manageUser: HotelMangementServicesService, private activeRoute: ActivatedRoute,public router:Router) {
  }

  ngOnInit(): void {

  }

  navigateTo(role:any) {
    console.log('role', role);
    
    this.router.navigate(['/Dashboard', role]);
  }

  onloginFormSubmit(LoginDetails: any) {
    const emailPattern = /^[a-z0-9]+@[a-z]+\.[a-z]{2,3}/;
    console.log("roleopted", this.optedRole);
    console.log("login data", LoginDetails.value);
    let isValid = true;

    if(this.email.length > 0 && emailPattern.test(this.email)){
      document.getElementById('loginEmail')?.classList.remove('redBorder');
    }else{
      isValid = false;
      document.getElementById('loginEmail')?.classList.add('redBorder');
    }

    if(this.password.length > 0 ){
      document.getElementById('loginPassword')?.classList.remove('redBorder');
    }else{
      isValid = false;
      document.getElementById('loginPassword')?.classList.add('redBorder');
    }

    if(isValid){
      this.addloginSubscription = this.manageUser.checkLoginData(LoginDetails.value).subscribe((data: any) => {
        console.log("response login", data);
        try{
          if(data.statusCode == 200) {
            localStorage.setItem('loginCredentials', data.userData)
            localStorage.setItem('loginUserRole', this.optedRole)
            this.router.navigate(['/Dashboard', this.optedRole]);
          }else{
            this.errorLoginservice = true;
          }
        }catch(e){
          this.errorLoginservice = true;
        }

      },error =>{
        this.errorLoginservice = true;
      });
    }
  }
  
}
