import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { SignupComponent } from './signup/signup.component';
import { ReceptionistComponent } from './receptionist/receptionist.component';
import { ManageguestComponent } from './manageguest/manageguest.component';
import { AddguestComponent } from './addguest/addguest.component';
import { SearchroomsComponent } from './searchrooms/searchrooms.component';
import { OwnerComponent } from './owner/owner.component';
import { OwnerdashboardComponent } from './ownerdashboard/ownerdashboard.component';
import { HeaderComponent } from './header/header.component';
import { FormsModule } from '@angular/forms';
import { ManagerdashboardComponent } from './managerdashboard/managerdashboard.component';
import { HotelMangementServicesService } from './services/hotel-mangement-services.service';
import { HttpClientModule } from '@angular/common/http';
import { DashboardsComponent } from './dashboards/dashboards.component';
import { NavigationComponent } from './navigation/navigation.component';
import { UsermanagementComponent } from './usermanagement/usermanagement.component';
import { SearchPipe } from './search.pipe';
import { SetratesComponent } from './setrates/setrates.component';
import { InventoryComponent } from './inventory/inventory.component';

import { RoomdetailsComponent } from './roomdetails/roomdetails.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    SignupComponent,
    ReceptionistComponent,
    ManageguestComponent,
    AddguestComponent,
    SearchroomsComponent,
    OwnerComponent,
    OwnerdashboardComponent,
    HeaderComponent,
    ManagerdashboardComponent,
    DashboardsComponent,
    NavigationComponent,
    UsermanagementComponent,
    SearchPipe,
    SetratesComponent,
    InventoryComponent,
   
    RoomdetailsComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [HotelMangementServicesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
