import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { HotelMangementServicesService } from '../services/hotel-mangement-services.service';

@Component({
  selector: 'app-roomdetails',
  templateUrl: './roomdetails.component.html',
  styleUrls: ['./roomdetails.component.css']
})
export class RoomdetailsComponent implements OnInit {
  successfullySubmited = false;
  roomName: any;
  buildingNumber: any;
  floorNumber: any;
  status: any;
  roomType: any;
  
  routeParameter: any;
  ReceptionistUser: any;
  addRoomdetailsSubscription: Subscription = new Subscription;
  errorRoomdetailsAdding = false;
  showError = false;
  // updateReceptionistSubscription: Subscription = new Subscription;

  constructor(public manageRoomdetails: HotelMangementServicesService, private activeRoute: ActivatedRoute, public router: Router) { }


  ngOnInit(): void {
    console.log('setrates loaded');
    
    this.activeRoute.params.subscribe(routeParams => {
      this.routeParameter = routeParams['id'];
    });
  }
  onRoomdetailsFormSubmit(RoomdetailsDetails: any) {
    console.log("details", RoomdetailsDetails.value);
    this.errorRoomdetailsAdding = false;
    this.successfullySubmited = false;
    let isValid = true;
    if (RoomdetailsDetails.valid) {
      this.showError = false;
    } else {
      isValid = false;
      this.showError = true;
    }

    
    
    if (isValid) {
      this.addRoomdetailsSubscription = this.manageRoomdetails.AddRoomdetails(RoomdetailsDetails.value).subscribe((data: any) => {
        console.log("response", data);
        this.successfullySubmited = true;
        RoomdetailsDetails.reset();
      },error =>{
        this.errorRoomdetailsAdding = true;
      });
    }

  }
}


